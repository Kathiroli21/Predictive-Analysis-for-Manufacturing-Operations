class Config:
    DEBUG = True
    UPLOAD_FOLDER = 'data'
    MODEL_PATH = 'models/model.pkl'
